# TODO

- remote `etcd` `consul`
- watch changed config files and reload
- [x] set default value on binding struct. use tag `defalut`

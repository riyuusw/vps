# common func for internal use

- don't depend on other external packages
package structs

// SMap simple map[string]string struct. TODO
type SMap struct {
	data map[string]string //lint:ignore U1000 for unused
}

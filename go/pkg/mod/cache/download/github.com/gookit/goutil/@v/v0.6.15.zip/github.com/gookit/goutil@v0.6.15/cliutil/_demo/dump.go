package main

import (
	"os"

	"github.com/gookit/goutil/dump"
)

func main() {
	dump.P(os.Args)
}

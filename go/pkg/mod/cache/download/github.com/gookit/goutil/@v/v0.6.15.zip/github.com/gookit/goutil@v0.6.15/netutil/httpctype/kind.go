package httpctype

// there commonly base type category list
const (
	KindForm     = "form"
	KindFormData = "dataForm"
	KindJSON     = "json"
	KindXML      = "xml"
	KindYAML     = "yaml"
)

# Stdio

`stdio` provide some standard IO util functions.

## Install

```bash
go get github.com/gookit/goutil/stdio
```

## Go docs

- [Go docs](https://pkg.go.dev/github.com/gookit/goutil/stdio)

## Usage

Please see tests.

## Testings

```shell
go test -v ./stdio/...
```

Test limit by regexp:

```shell
go test -v -run ^TestSetByKeys ./stdio/...
```

Package errorx provide a enhanced error implements, allow with call stack and wrap another error.


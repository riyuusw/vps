// Package syncs provides synchronization primitives util functions.
package syncs

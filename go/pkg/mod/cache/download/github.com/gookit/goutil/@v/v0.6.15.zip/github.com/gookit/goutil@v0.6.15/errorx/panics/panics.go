// Package panics provides functions to handle panic assertions.
package panics

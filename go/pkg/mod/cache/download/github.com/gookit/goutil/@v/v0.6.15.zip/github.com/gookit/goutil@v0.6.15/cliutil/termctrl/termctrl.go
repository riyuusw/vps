// Package termctrl provide some simple term control utils
package termctrl

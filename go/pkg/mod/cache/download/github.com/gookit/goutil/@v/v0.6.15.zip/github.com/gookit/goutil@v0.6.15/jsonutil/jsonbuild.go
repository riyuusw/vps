package jsonutil

/*
TODO json build
type JsonBuilder struct {
	Indent string
	// mu  sync.Mutex
	// cfg *CConfig
	buf bytes.Buffer
	out io.Writer
}

// AddField add field to json
func (b *JsonBuilder) AddField(key string, value any) *JsonBuilder {
	b.buf.WriteString(`,"`)
	b.buf.WriteString(key)
	b.buf.WriteString(`":`)
	b.encode(value)
	return b
}
*/

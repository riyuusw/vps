package structs

// MapStruct simple copy src struct value to dst struct
// func MapStruct(srcSt, dstSt any) {
// 	// TODO
// }

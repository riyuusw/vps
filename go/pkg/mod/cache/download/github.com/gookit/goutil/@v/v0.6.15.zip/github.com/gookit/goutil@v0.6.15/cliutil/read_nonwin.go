//go:build !windows

package cliutil

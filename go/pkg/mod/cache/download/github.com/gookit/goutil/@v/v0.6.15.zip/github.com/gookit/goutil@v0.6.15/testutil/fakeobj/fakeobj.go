// Package fakeobj provides a fake object for testing. such as fake
// fs.File, fs.FileInfo, fs.DirEntry etc.
package fakeobj

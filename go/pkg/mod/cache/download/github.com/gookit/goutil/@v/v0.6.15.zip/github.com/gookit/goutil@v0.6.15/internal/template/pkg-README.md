# Map Utils

- some features

## Install

```bash
go get github.com/gookit/goutil/maputil
```

## Go docs

- [Go docs](https://pkg.go.dev/github.com/gookit/goutil/maputil)

## Usage


## Testings

```shell
go test -v ./maputil/...
```

Test limit by regexp:

```shell
go test -v -run ^TestSetByKeys ./maputil/...
```
